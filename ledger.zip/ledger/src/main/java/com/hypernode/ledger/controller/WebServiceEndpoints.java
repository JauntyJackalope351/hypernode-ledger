package com.hypernode.ledger.controller;

import com.fasterxml.jackson.core.type.TypeReference;
import com.hypernode.ledger.ErrorHandling;
import com.hypernode.ledger.client.ExternalPayment;
import com.hypernode.ledger.contracts.*;
import com.hypernode.ledger.contracts.DistributedLedgerAccount;
import com.hypernode.ledger.encryptionInterfaces.Encryption;
import com.hypernode.ledger.encryptionInterfaces.EncryptionEntity_ExternalServer;
import com.hypernode.ledger.encryptionInterfaces.EncryptionEntity_Integrated;
import com.hypernode.ledger.webService.WebServiceCaller;
import com.hypernode.ledger.webService.WebServiceEngine;
import com.hypernode.ledger.webService.WebServiceInitializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * REST Controller for managing distributed ledger web service endpoints.
 * Provides HTTP endpoints for ledger operations, account management, authentication,
 * and validator node interactions in a distributed blockchain system.
 */
@Controller("/hdls")
public class WebServiceEndpoints
{
    @Autowired
    public WebServiceEngine webServiceEngine;

    private static final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();

    /**
     * Displays the home page of the web service.
     * Sets up model attributes for the home template rendering.
     *
     * @param model Spring MVC model for passing data to the view
     * @return String view name "home" which corresponds to home.html template
     */
    @GetMapping("/hdls")
    public String home(Model model) {
        return "home"; // Corresponds to home.html
    }

    @ResponseBody
    @GetMapping("/hdls/version")
    public String getVersion() {
        return "2025.10.04.1";
    }


    /**
     * Completes the initialization process for a new node joining the network.
     * This is called asynchronously after successful authentication to provide
     * the latest validated data contract to the newly joined node.
     *
     * @param _lastDataContract StatusDataContract containing the most recent
     *                         validated state of the distributed ledger
     */
    @ResponseBody
    @PostMapping("/hdls/initialize")
    public boolean initialize(@RequestBody StatusDataContract _lastDataContract) {
        WebServiceInitializer.initialize(webServiceEngine, _lastDataContract);
        //this.webServiceEngine.TimedReadingEvent();
        this.startTimer();
        return true;
    }

    /**
     * Provides a challenge string that must be digitally signed for authentication.
     * This string is used in the two-phase authentication process where clients
     * must prove ownership of their private key by signing this challenge.
     *
     * @return String challenge text that must be signed with the client's private key
     */
    @ResponseBody
    @GetMapping("/hdls/requestAuthenticationStringToSign")
    public String requestAuthenticationStringToSign() {
        return webServiceEngine.requestAuthenticationStringToSign();
    }

    /**
     * Record class for server authentication requests.
     * Contains all necessary information for validating a server's identity and connection.
     *
     * @param publicKey String Base64 encoded public key of the requesting server
     * @param signedMessage String Base64 encoded signature of the challenge string
     * @param connectionString String connection details for reaching the requesting server
     * @param signedConnectionString String Base64 encoded signature of the connection string
     */
    public record AuthenticateServerRequest(String publicKey, String signedMessage, String connectionString, String signedConnectionString){
    }

    /**
     * Authenticates a server attempting to join the network.
     * Verifies that the requesting server owns the private key corresponding
     * to their claimed public key by validating their digital signature.
     *
     * @param request AuthenticateServerRequest containing the public key, signed challenge,
     *               connection string, and signed connection string for verification
     * @return boolean true if authentication succeeds and server is accepted into network,
     *         false if authentication fails
     */
    @ResponseBody
    @PostMapping("/hdls/authenticateServer")
    public boolean authenticateServerWrapper(@RequestBody AuthenticateServerRequest request) {
        return webServiceEngine.authenticateServer(request.publicKey, request.signedMessage, request.connectionString, request.signedConnectionString );
    }

    /**
     * Retrieves the current transport message being transmitted across the network.
     * This endpoint provides access to the latest block data and can be used
     * for network synchronization and as a cached response in CDN deployments.
     *
     * @return TransportMessageDataContract containing the current block data
     *         and transaction information being propagated through the network
     */
    @ResponseBody
    @GetMapping("/hdls/getCurrentlyTransmittedTransportMessage")
    public TransportMessageDataContract getCurrentlyTransmittedTransportMessage()
    {
        return webServiceEngine.getCurrentlyTransmittedTransportMessage();
    }


    /**
     * Retrieves the current status of the distributed ledger system.
     * Provides comprehensive information about accounts, balances, validator nodes,
     * and system parameters. Useful for monitoring and debugging the ledger state.
     *
     * @return StatusDataContract containing complete system status including
     *         account balances, validator information, and current parameters
     */
    @ResponseBody
    @GetMapping("/hdls/getStatus")
    public StatusDataContract getStatus()
    {
        StatusDataContract ret;
        ret = webServiceEngine.getStatusDataContract();
        return ret;
        //return webServiceEngine.getStatusDataContract();
    }

    /**
     * Retrieves the public key that is used in this node.
     *
     * @return the public key, in string form
     */
    @ResponseBody
    @GetMapping("/hdls/getPublicKey")
    public String getPublicKey()
    {
        return this.webServiceEngine.getEncryptionEntity().getPublicKey();
    }


    /**
     * Retrieves account information for a specific public key.
     * Returns the account details including balance and validator assignment.
     *
     * @param _publicKey String public key of the account to query
     * @return DistributedLedgerAccount containing account details and current balance,
     *         or null if the account is not found
     */
    @ResponseBody
    @PostMapping("/hdls/AccountTotals")
    public DistributedLedgerAccount AccountTotal(@RequestBody String _publicKey) {
        return DistributedLedgerAccount.find(webServiceEngine.getStatusDataContract().getAccountsList(), _publicKey.replace("\"",""));
    }

    /**
     * Submits a list of payment transactions to be included in the next block.
     * Validates and queues the transactions for processing by the network consensus.
     * Each payment must be properly signed by the sender's private key.
     *
     * @param _requestedPayments List of ExternalPayment objects containing transaction details
     *                          including sender, recipient, amount, and digital signature
     * @return List<ExternalPayment> processed payments with validation results
     *         and transaction IDs assigned by the system
     */
    @ResponseBody
    @PostMapping("/hdls/spend")
    public List<ExternalPayment> spendList(@RequestBody List<ExternalPayment> _requestedPayments) {
        return webServiceEngine.notifySpend(_requestedPayments);
    }



    /**
     * Submits a voting delegation change to the network.
     * Allows account holders to delegate their voting rights to validator nodes
     * for parameter changes and network governance decisions.
     *
     * @param _accountAttributesUpdate VotingDelegation object containing the delegation details
     *                         including delegator, delegate, and digital signature
     */
    @ResponseBody
    @PostMapping("/hdls/updateAccountAttributes")
    public String updateAccountAttributes(@RequestBody AccountAttributesUpdate _accountAttributesUpdate) {
        return  webServiceEngine.notifyupdateAccountAttributes(_accountAttributesUpdate);
    }

    /**
     * Manually processes a transport message data contract.
     * This endpoint allows for manual injection of transport messages,
     * typically used for testing or recovery scenarios.
     *
     * @param transportMessageDataContract TransportMessageDataContract containing
     *                                   the message data to be processed by the system
     */
    @ResponseBody
    @PostMapping("/hdls/processTransportMessageDataContract")
    public void manualProcessTransportMessageDataContract(@RequestBody TransportMessageDataContract transportMessageDataContract) {
        webServiceEngine.receiveData(transportMessageDataContract);
    }

    /**
     * Retrieves the available balance for a specific account.
     * Returns the current spendable amount for the given public key.
     *
     * @param publicKey String public key of the account to query
     * @return BigDecimal representing the available balance for the specified account
     */
    @ResponseBody
    @GetMapping("/hdls/getAmount")
    public BigDecimal getAmount(String publicKey) {
        return webServiceEngine.getAmountAvailable(publicKey);
    }

    /**
     * Retrieves the current block ID being processed by the system.
     * Useful for synchronization and determining the current state of the ledger.
     *
     * @return int current block ID that is being transmitted across the network
     */
    @ResponseBody
    @GetMapping("/hdls/getBlockId")
    public int getBlockId()
    {
        return this.webServiceEngine.getBlockId();
    }

    @ResponseBody
    @GetMapping("/hdls/getLedgerHistory")
    public LedgerHistory getLedgerHistory()
    {
        return this.webServiceEngine.getLedgerHistory();
    }
    @ResponseBody
    @GetMapping("/hdls/getLedgerHistoryInterval")
    public LedgerHistory getLedgerHistoryInterval(int start, int end)
    {
        return this.webServiceEngine.getLedgerHistory().getInterval(start,end);
    }

    @ResponseBody
    @GetMapping("/hdls/setNewLedgerHistoryOrigin")
    public String setNewLedgerOrigin( @RequestBody int id)
    {
        this.webServiceEngine.getLedgerHistory().changeOriginalContract(id);
        return "OK";
    }

    @ResponseBody
    @PostMapping("/hdls/getAccountInfo")
    public AccountInfo getAccountInfo(@RequestBody String  id)
    {
        AccountInfo ret;

        ret = this.webServiceEngine.getAccountInfo(id.replace("\"",""));
        return ret;
    }

    @ResponseBody
    @PostMapping("/hdls/receivePreviousMessageSignature")
    public String receivePreviousMessageSignature(@RequestBody Signature  signature)
    {
        String ret = this.webServiceEngine.addPreviousBlockRevisionResultSignature(signature);
        return ret;
    }

    @ResponseBody
    @PostMapping("/hdls/getIPAddress")
    public String getIPAddress(@RequestBody String id)
    {
        AccountInfo ret;
        ret = this.webServiceEngine.getAccountInfo(id.replace("\"",""));
        return ret.getNode().ipAddress();
    }

    public void startTimer() {

        //this.webServiceEngine.startTimer();
        ErrorHandling.logEvent("startTimer",false,null);
        //starting from the hour to soft align the timescales
        final long epochNow = Instant.now().toEpochMilli();
        final long epochHourInMilli = epochNow - Math.floorMod(Instant.now().toEpochMilli(), 1000 * 60 * 60);
        final long schedulerMargin = webServiceEngine.getStatusDataContract().getLedgerParameters().getFrameProcessingTimeMilliseconds();
        final long timePerFrame =  Math.divideExact( 1000*60*60 ,Math.max(webServiceEngine.getStatusDataContract().getLedgerParameters().getMessageUpdateFrequencyPerHour(),1));
        int counter;
        //find the time of the start of the next blockTempVersion that happens in the future
        counter = (int) ((epochNow - epochHourInMilli + schedulerMargin) / timePerFrame);
        counter++;
        //and then get the time interval so that it starts on time
        long interval = (epochHourInMilli + (counter * timePerFrame)) - epochNow;
        long interval2 = interval + schedulerMargin;
        try
        {
            scheduler.schedule(this::TimedUpdatingEvent, interval, TimeUnit.MILLISECONDS);
            scheduler.schedule(this::TimedReadingEvent, interval2, TimeUnit.MILLISECONDS);
            scheduler.schedule(this::startTimer,interval2 + 1000,TimeUnit.MILLISECONDS);
        }
        catch (Exception e)
        {
            ErrorHandling.logEvent("error WebServiceEndpoint.startTimer",true,e);
            //throw new RuntimeException("fail");
        }

    }
    public void TimedUpdatingEvent()
    {
        this.webServiceEngine.TimedUpdatingEvent();
    }
    public void TimedReadingEvent()
    {
        this.webServiceEngine.TimedReadingEvent();
    }

    /**
     * Displays the server status page showing current server information.
     * Includes the server's public key and the hash of the last processed block.
     *
     * @param model Spring MVC model for passing server status data to the view
     * @return String view name "server" which corresponds to server.html template
     */
    @GetMapping("/hdls-server-admin")
    public String server(Model model) {
        String publicKey = "PUBLIC_KEY";
        String lastHash = "LAST_HASH";
        if(this.webServiceEngine.getEncryptionEntity() != null)
        {
            publicKey = this.webServiceEngine.getEncryptionEntity().getPublicKey();
        }
        if(this.webServiceEngine.getStatusDataContract() != null)
        {
            lastHash = this.webServiceEngine.getStatusDataContract().getHash();
        }
        model.addAttribute("publicKey", publicKey);
        model.addAttribute("lastHash", lastHash);
        return "server"; // Corresponds to home.html
    }


    /**
     * Sets the encryption entity for integrated key management.
     * Validates the provided keys by testing message signing before acceptance.
     * This method configures the server to use locally stored private keys.
     *
     * @param jsonInput EncryptionEntity_Integrated object containing public and private keys
     * @return String status message: "OK" if successful, "Already Started" if already configured,
     *         or "Invalid Keys" if the key validation fails
     */
    @ResponseBody
    @PostMapping("/hdls-server-admin/setEncryptionEntityIntegrated")
    public String setEncryptionEntityIntegrated(@RequestBody EncryptionEntity_Integrated jsonInput) {
        String testMessage = "the quick brown fox jumps over the lazy dog"; //TODO use a randomized string, even the previous hash would be fine
        if(webServiceEngine.getEncryptionEntity() != null) {
            return "Already Started";
        }
        if(!Encryption.verifySignedMessage(testMessage,jsonInput.getPublicKey(),jsonInput.signMessage(testMessage)))
        {
            return "Invalid Keys";
        }
        webServiceEngine.setEncryptionEntity(jsonInput);
        return "OK";
    }

    /**
     * Sets the encryption entity for external server key management.
     * Configures the server to use an external signing service for cryptographic operations.
     * Validates the connection by testing message signing before acceptance.
     *
     * @param jsonInput EncryptionEntity_ExternalServer object containing connection details
     * @return String status message: "OK" if successful, "Already Started" if already configured,
     *         or "Invalid Keys" if the external server validation fails
     */
    @ResponseBody
    @PostMapping("/hdls-server-admin/setEncryptionEntityExternalServer")
    public String setEncryptionEntityExternalServer(@RequestBody EncryptionEntity_ExternalServer jsonInput) {
        String testMessage = "the quick brown fox jumps over the lazy dog";
        if(webServiceEngine.getEncryptionEntity() != null) {
            return "Already Started";
        }
        if(!Encryption.verifySignedMessage(testMessage,jsonInput.getPublicKey(),jsonInput.signMessage(testMessage)))
        {
            return "Invalid Keys";
        }
        webServiceEngine.setEncryptionEntity(jsonInput);
        return "OK";
    }


    /**
     * Initializes and creates a new distributed ledger with the provided configuration.
     * This method sets up the genesis block and initial validator nodes.
     * Requires that an encryption entity has been previously configured.
     *
     * @param startingData StatusDataContract containing initial ledger configuration,
     *                    including validator nodes, accounts, and ledger parameters
     * @return String status message: "OK" if successful, "Already configured" if ledger exists,
     *         or "Set Encryption entity first" if no encryption entity is configured
     */
    @ResponseBody
    @PostMapping("/hdls-server-admin/initCreateNewLedger")
    public String initCreateNewLedger(@RequestBody StatusDataContract startingData) {
        ValidatorNode validatorNode;
        if(webServiceEngine.getStatusDataContract() != null)
        {
            return "Already configured";
        }
        if(webServiceEngine.getEncryptionEntity() == null)
        {
            return "Set Encryption entity first";
        }
        Optional<ValidatorNode> validatorNodeOptional = startingData.getValidatorNodeList().stream().filter(v -> v.getPublicKey().equals(webServiceEngine.getEncryptionEntity().getPublicKey())).findFirst();
        if(validatorNodeOptional.isEmpty())
        {
            return "Current validator node not found in Status contract";
        }
        validatorNode = validatorNodeOptional.get();
        if(!ValidatorNode.validateConnectionString(validatorNode.getConnectionString()))
        {
            return "Invalid connection string";
        }
        if(validatorNode.getAddress() == null)
        {
            Map<Integer,Integer> address = new HashMap<Integer,Integer>();
            address.put(1,0);
            validatorNode.setAddress(address);
        }
        validatorNode.setSignature(
                webServiceEngine.getEncryptionEntity().signMessage(
                        validatorNode.getStringToSign()
                ));

        webServiceEngine.setThisValidatorNode(validatorNode);
        WebServiceInitializer.initAndCreateNewLedger(webServiceEngine, startingData);
        this.startTimer();
        return "OK";
    }


    /**
     * Record class for join existing ledger requests.
     * Contains the connection strings needed for a node to join an existing network.
     *
     * @param thisConnectionString String connection string for this node
     * @param connectionStringDestination String connection string of the target node to connect to
     */
    public record joinExistingLedgerRequest(String thisConnectionString, String connectionStringDestination){
    }

    /**
     * Joins an existing distributed ledger network by connecting to a known validator node.
     * Initiates the authentication and synchronization process with the existing network.
     *
     * @param _request joinExistingLedgerRequest containing this node's connection string
     *                and the destination node's connection string for initial contact
     * @return String status message indicating success or failure of the join operation
     */
    @ResponseBody
    @PostMapping("/hdls-server-admin/joinExistingLedger")
    public String joinExistingLedger(@RequestBody joinExistingLedgerRequest _request) {
        String ret;
        if(webServiceEngine.getStatusDataContract() != null)
        {
            return "Already Started";
        }
        return WebServiceInitializer.joinExistingLedger(webServiceEngine, _request.connectionStringDestination, _request.thisConnectionString);
    }




    /**
     * Submits a vote for changing ledger parameters.
     * Allows validator nodes to propose modifications to system parameters
     * such as transaction costs, block timing, and validation requirements.
     *
     * @param _LedgerParameters LedgerParameters object containing the proposed
     *                         parameter changes to be voted on by the network
     */
    @ResponseBody
    @PostMapping("/hdls-server-admin/changeVotedParameters")
    public void changeVotedParameters(@RequestBody LedgerParameters _LedgerParameters)//, String signatureBase64)
    {
        //if(Encryption.verifySignedMessage(_LedgerParameters.getStringToSign(), webServiceEngine.getEncryptionEntity().getPublicKey(),Encryption.base64ToByteArray(signatureBase64)))
        //{
        webServiceEngine.getPendingNextMessage().setVotedParameterChanges(_LedgerParameters);
        //}
    }


    @ResponseBody
    @PostMapping("/hdls-server-admin/generatePreviousMessageSignature")
    public String generatePreviousMessageSignature(@RequestBody String  connectionString)
    {
        BlockRevisionResult result = new BlockRevisionResult();

        StatusDataContract statusDataContract = WebServiceCaller.callServerMethodThrows(connectionString, "hdls/getStatus", null,new TypeReference<>() {});
        TransportMessageDataContract transportMessageDataContract = WebServiceCaller.callServerMethodThrows(
                connectionString,
                "hdls/getCurrentlyTransmittedTransportMessage",
                null,
                new TypeReference<>() {
                }
        );

        TransportMessageDataContract myTransportMessageDataContract = new TransportMessageDataContract();
        myTransportMessageDataContract.setBlockId(transportMessageDataContract.getBlockId());
        myTransportMessageDataContract.setBlockRevision(transportMessageDataContract.getBlockRevision());
        myTransportMessageDataContract.setBlockTempVersion(transportMessageDataContract.getBlockTempVersion());
        myTransportMessageDataContract.setSignedValidatorMessages( new HashSet<>());
        myTransportMessageDataContract.signContract(this.webServiceEngine.getEncryptionEntity());
        myTransportMessageDataContract.computeHash();

        transportMessageDataContract.nameToPublicKey(statusDataContract.getDistributedLedgerAccounts());
        myTransportMessageDataContract.storeDataContract(transportMessageDataContract, this.webServiceEngine.getEncryptionEntity());

        result.init(myTransportMessageDataContract,myTransportMessageDataContract,statusDataContract);
        Signature s = Signature.create(this.webServiceEngine.getEncryptionEntity().getPublicKey(),result.getStringToSign(), this.webServiceEngine.getEncryptionEntity().signMessage(result.getStringToSign()));
        String ret = WebServiceCaller.callServerMethodThrows(connectionString, "hdls/receivePreviousMessageSignature", s,new TypeReference<String>() {});
        return ret;
    }
    //TODO generate the screen to trigger generatePreviousMessageSignature


    /**
     * Displays the form page for setting up integrated encryption entity.
     * Provides a user interface for inputting public and private keys.
     *
     * @param model Spring MVC model for passing form configuration to the view
     * @return String view name "JSONInput" for the key input form
     */
    @GetMapping("/hdls-server-admin/setEncryptionEntityIntegrated")
    public String clientSetEncryptionEntityIntegrated(Model model) {
        model.addAttribute("apiEndpoint","/hdls-server-admin/setEncryptionEntityIntegrated");
        model.addAttribute("title","Set Encryption Entity (Integrated)");
        model.addAttribute("info","");
        model.addAttribute("jsonLabel","Paste JSON here:");
        model.addAttribute("jsonDefault","{\n" +
                "\"publicKey\":\n" +
                "\"PUBLIC_KEY\",\n" +
                "\"privateKey\":\n" +
                "\"PRIVATE_KEY\"\n" +
                "}");
        return "JSONInput";
    }
    /**
     * Displays the form page for setting up external server encryption entity.
     * Provides a user interface for inputting external server connection details.
     *
     * @param model Spring MVC model for passing form configuration to the view
     * @return String view name "JSONInput" for the external server connection form
     */
    @GetMapping("/hdls-server-admin/setEncryptionEntityExternalServer")
    public String setEncryptionEntityExternalServer(Model model) {
        model.addAttribute("apiEndpoint","/hdls-server-admin/setEncryptionEntityExternalServer");
        model.addAttribute("title","Set Encryption Entity (Integrated)");
        model.addAttribute("info","");
        model.addAttribute("jsonLabel","Paste connection string here:");
        model.addAttribute("jsonDefault", "");
        return "JSONInput";
    }
    /**
     * Displays the form page for creating a new ledger.
     * Pre-populates the form with default configuration including the current server's public key.
     *
     * @param model Spring MVC model for passing form configuration to the view
     * @return String view name "JSONInput" for the new ledger creation form
     */
    @GetMapping("/hdls-server-admin/createNewLedger")
    public String initCreateNewLedgerGet(Model model) {
        String publicKey = "PUBLIC_KEY";
        if(this.webServiceEngine.getEncryptionEntity() != null)
        {
            publicKey = this.webServiceEngine.getEncryptionEntity().getPublicKey();
        }
        model.addAttribute("apiEndpoint","/hdls-server-admin/initCreateNewLedger");
        model.addAttribute("title","Create new Ledger");
        model.addAttribute("info","");
        model.addAttribute("jsonLabel","Paste JSON here:");
        model.addAttribute("jsonDefault","{\n" +
                "\"id\": 1,\n" +
                "\"distributedLedgerAccounts\":[\n" +
                "{\n" +
                "    \"publicKey\":\"" + publicKey +"\",\n" +
                "    \"name\": \"ACCOUNT1_NAME\",\n" +
                "    \"amount\": \"1000.00\",\n" +
                "    \"validatorNode\":\"" + publicKey +"\"\n" +
                "}],\n" +
                "\"validatorNodeList\":[{\n" +
                "    \"connectionString\": \"CONNECTION_STRING\",\n" +
                "    \"publicKey\":\"" + publicKey +"\"\n" +
                "}],\n" +
                "\"ledgerParameters\":{\n" +
                "    \"messageUpdateFrequencyPerHour\": 30,\n" +
                "    \"frameProcessingTimeMilliseconds\": 5000,\n" +
                "    \"maxConnections\": 20,\n" +
                "    \"amountRequestedToBeValidator\": \"1\",\n" +
                "    \"transactionCost\": \"0.1\",\n" +
                "    \"maxTransactionsPerBlock\": 1000,\n" +
                "    \"transmitRedundancy\": 1\n" +
                "}\n" +
                "}");
        return "JSONInput";
    }

    /**
     * Displays the form page for joining an existing ledger.
     * Provides interface for specifying connection strings for network joining.
     *
     * @param model Spring MVC model for passing form configuration to the view
     * @return String view name "JSONInput" for the join ledger form
     */
    @GetMapping("/hdls-server-admin/joinExistingLedger")
    public String joinExistingLedgerGet(Model model) {
        model.addAttribute("apiEndpoint","/hdls-server-admin/joinExistingLedger");
        model.addAttribute("title","Join existing Ledger");
        model.addAttribute("info","");
        model.addAttribute("jsonLabel","Paste JSON here:");
        model.addAttribute("jsonDefault","{\n" +
                "\"thisConnectionString\":\"thisConnectionString\",\n" +
                "\"connectionStringDestination\":\"connectionStringDestination\"\n" +
                "}");
        return "JSONInput";
    }
    /**
     * Displays the form page for submitting payment transactions.
     * Provides interface for creating and submitting spend transactions to the network.
     *
     * @param model Spring MVC model for passing form configuration to the view
     * @return String view name "JSONInput" for the payment submission form
     */
    @GetMapping("/hdls-server-admin/spend")
    public String spendListGet(Model model) {
        model.addAttribute("apiEndpoint","/hdls/spend");
        model.addAttribute("title","Receive spend messages");
        model.addAttribute("info","");
        model.addAttribute("jsonLabel","Paste JSON here:");
        model.addAttribute("jsonDefault", "[\n" +
                "{\n" +
                "\"publicKeyFrom\":\"PUBLIC_KEY_FROM\",\n" +
                "\"publicKeyTo\":\"PUBLIC_KEY_TO\",\n" +
                "\"paymentComment\":\"COMMENT\",\n" +
                "\"amount\": \"1.00\",\n" +
                "\"blockId\": 2\n" +
                "},\n" +
                "{\n" +
                "\"publicKeyFrom\":\"PUBLIC_KEY_FROM\",\n" +
                "\"publicKeyTo\":\"PUBLIC_KEY_TO\",\n" +
                "\"paymentComment\":\"COMMENT\",\n" +
                "\"amount\": \"1.00\",\n" +
                "\"blockId\": 2\n" +
                "}\n" +
                "]");
        return "JSONInput";
    }
    /**
     * Displays the form page for changing vote delegation.
     * Provides interface for account holders to delegate their voting rights.
     *
     * @param model Spring MVC model for passing form configuration to the view
     * @return String view name "JSONInput" for the vote delegation form
     */
    @GetMapping("/hdls-server-admin/updateAccountAttributes")
    public String voteDelegation(Model model) {
        model.addAttribute("apiEndpoint","/hdls/updateAccountAttributes");
        model.addAttribute("title","update Account Attributes");
        model.addAttribute("info","");
        model.addAttribute("jsonLabel","Paste JSON here:");
        model.addAttribute("jsonDefault","{\n" +
                "\"from\": \"ACCOUNT_PUBLIC_KEY\",\n" +
                "\"name\": \"ACCOUNT_NEW_NAME\",\n" +
                "\"delegated\": \"PUBLIC_KEY_SERVER\",\n" +
                "\"blockId\": 5,\n" +
                "\"previousRevisionHash\": \"HASH\",\n" +
                "\"signatureValue\": \"SIGNATURE\"\n" +
                "}");
        return "JSONInput";
    }

    /**
     * Displays the form page for changing voted parameters.
     * Provides interface for validator nodes to submit parameter change proposals.
     *
     * @param model Spring MVC model for passing form configuration to the view
     * @return String view name "JSONInput" for the parameter change form
     */
    @GetMapping("/hdls-server-admin/changeVotedParameters")
    public String changeVotedParameters(Model model) {
        model.addAttribute("apiEndpoint","/hdls-server-admin/changeVotedParameters");
        model.addAttribute("title","Change Voted Parameters");
        model.addAttribute("info","");
        model.addAttribute("jsonLabel","Paste JSON here:");
        model.addAttribute("jsonDefault","{\n" +
                "\"messageUpdateFrequencyPerHour\": 30,\n" +
                "\"frameProcessingTimeMilliseconds\": 5000,\n" +
                "\"maxConnections\": 20,\n" +
                "\"amountRequestedToBeValidator\": \"1\",\n" +
                "\"transactionCost\": \"0.1\",\n" +
                "\"maxTransactionsPerBlock\": 1000,\n" +
                "\"distributedLedgerAccountReassignProposals\": [\n" +
                "{\n" +
                "    \"publicKey\":\"" +
                "MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAunH4nCceRoBkLW1Ec0j4plIxBnUVH6LcPRk2s5wGOrW8SP7gdMHH2wywh7fVTH8GWo0VLr/9Wz1kyS8GWm3XOTmlX0YEyz1ogHBSy4Sp2cDls5XMX9ct4SssMoz6EU+tkHcNYHyM0KUd8hvynrT7YTbCxSWJKmz+Wez1K93wb+jV6pi4tH9x0+4fyxq38Z3z/MK7U/D00neOCMQGB7KH0qUrTG6ZEB57X4h1frOmmwvBqnQiGDDdsVf+yHJEvbPJjoCshg8l3O3TxqZutzEup7D2tPDKkm8xmRGl1FqoWaHoa86urW1+JOrIpaUhujLZWgGUuKv6yyF47MdKV4PbQMDmbHAXhLM81wbnnv7nYpNIOwTA93OXjHPfKH2EkCP2a7U/qz9H6Oe7lKyd9oxkbcdXxU2+bbtO94mgBPsIewhspBuUWyqgXeJo8ByI73j6ynow0vIc7v8EHRuLPgAZl2/zmXuwIChYf46w8auNeMV68aNll+Au1ILE5SGy3kHRAgMBAAE=" +
                "\",\n" +
                "    \"name\": \"SHINJI\",\n" +
                "    \"amount\": \"1000.00\",\n" +
                "    \"validatorNode\":\"" +
                "MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAunH4nCceRoBkLW1Ec0j4plIxBnUVH6LcPRk2s5wGOrW8SP7gdMHH2wywh7fVTH8GWo0VLr/9Wz1kyS8GWm3XOTmlX0YEyz1ogHBSy4Sp2cDls5XMX9ct4SssMoz6EU+tkHcNYHyM0KUd8hvynrT7YTbCxSWJKmz+Wez1K93wb+jV6pi4tH9x0+4fyxq38Z3z/MK7U/D00neOCMQGB7KH0qUrTG6ZEB57X4h1frOmmwvBqnQiGDDdsVf+yHJEvbPJjoCshg8l3O3TxqZutzEup7D2tPDKkm8xmRGl1FqoWaHoa86urW1+JOrIpaUhujLZWgGUuKv6yyF47MdKV4PbQMDmbHAXhLM81wbnnv7nYpNIOwTA93OXjHPfKH2EkCP2a7U/qz9H6Oe7lKyd9oxkbcdXxU2+bbtO94mgBPsIewhspBuUWyqgXeJo8ByI73j6ynow0vIc7v8EHRuLPgAZl2/zmXuwIChYf46w8auNeMV68aNll+Au1ILE5SGy3kHRAgMBAAE=" +
                "\"\n" +
                "},\n" +
                "{\n" +
                "    \"publicKey\":\"" +
                "MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAk5GJ451dsBR9rPqxDmWEOab/FVIYItP2O8JHjCe6Pfvf+73vJuXIRLs+yZxohAp++zqmguo1gXJHZsVn4CVvEWlmitOCm4U7P3HugOXtiQJjBpK0U9gz+4s+qMSBEE+zSTZq+1QCUXESzoQ/+bGfnYTsH7xYk2BqexCwi4TAxSLclqJrDRGkRX8AynR4A8KjnJZjlFmtYaHNalpVuLMIorRd5IEYhIlf/mgmFyJwSpcJq+PozR7yDZFrMg2388e1Z4N8DjcxlaDpEguzdRCpd6pRW9Akb1jvfOlZJ4g394+cvz3ybrRM4jv4BfCyWicrG6THPz/ACz8YOIqGqcM3M/JdtKUe7aoxYwY+CzHA+1lyaJxigjU16uesAmv4pqxtqlTspeIiYzj5WoW3QpCWD1sC+amlDo2bpz8l3N5gFLqOaX2LAl8NYAOOPOHcHkp7Lj9/BUHV9uCpbLYxO8NFD8ubTpFooaKR6g9MCdZ4zTF6SxkRuk0l5wfANSUIYoxvAgMBAAE=" +
                "\",\n" +
                "    \"name\": \"AURON\",\n" +
                "    \"amount\": \"1000.00\",\n" +
                "    \"validatorNode\":\"" +
                "MIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAk5GJ451dsBR9rPqxDmWEOab/FVIYItP2O8JHjCe6Pfvf+73vJuXIRLs+yZxohAp++zqmguo1gXJHZsVn4CVvEWlmitOCm4U7P3HugOXtiQJjBpK0U9gz+4s+qMSBEE+zSTZq+1QCUXESzoQ/+bGfnYTsH7xYk2BqexCwi4TAxSLclqJrDRGkRX8AynR4A8KjnJZjlFmtYaHNalpVuLMIorRd5IEYhIlf/mgmFyJwSpcJq+PozR7yDZFrMg2388e1Z4N8DjcxlaDpEguzdRCpd6pRW9Akb1jvfOlZJ4g394+cvz3ybrRM4jv4BfCyWicrG6THPz/ACz8YOIqGqcM3M/JdtKUe7aoxYwY+CzHA+1lyaJxigjU16uesAmv4pqxtqlTspeIiYzj5WoW3QpCWD1sC+amlDo2bpz8l3N5gFLqOaX2LAl8NYAOOPOHcHkp7Lj9/BUHV9uCpbLYxO8NFD8ubTpFooaKR6g9MCdZ4zTF6SxkRuk0l5wfANSUIYoxvAgMBAAE=" +
                "\"\n" +
                "}\n" +
                "]}");
        return "JSONInput";
    }

    /**
     * Displays the form page for adding your signature for messages onto an external validator node.
     * Provides interface for specifying connection strings for network joining.
     *
     * @param model Spring MVC model for passing form configuration to the view
     * @return String view name "JSONInput" for the join ledger form
     */
    @GetMapping("/hdls-server-admin/generatePreviousMessageSignature")
    public String generatePreviousMessageSignatureGet(Model model) {
        model.addAttribute("apiEndpoint","/hdls-server-admin/generatePreviousMessageSignature");
        model.addAttribute("title","Cosign a message for a connected endpoint");
        model.addAttribute("info","");
        model.addAttribute("jsonLabel","Paste server connection string here:");
        model.addAttribute("jsonDefault","");
        return "JSONInput";
    }
}