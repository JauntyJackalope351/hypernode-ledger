package com.hypernode.ledger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DistributedLedgerApplication {
    public static void main(String[] args) {
        SpringApplication.run(DistributedLedgerApplication.class, args);
    }
}
